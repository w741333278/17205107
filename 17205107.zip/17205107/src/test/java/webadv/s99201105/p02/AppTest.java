package webadv.s99201105.p02;

import static org.junit.Assert.assertTrue;


import org.junit.Assert;
import org.junit.Test;
public class AppTest {
    private String INPUT1 = "zhangkehan";
    private String INPUT2 = "17205107";
    @Test
    public void testLength() {
        Assert.assertEquals(10, INPUT1.length());
    }
    @Test
    public void testHex() {
        Assert.assertEquals(8, INPUT2.length());
    }
}

