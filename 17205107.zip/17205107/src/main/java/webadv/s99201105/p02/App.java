package webadv.s99201105.p02;


import org.apache.commons.codec.digest.DigestUtils;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Properties;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class App{
	private String propFile;
 
	public App(String propFile) {
		this.propFile = propFile;
	}
	//从属性文件中进行用户名密码验证登录
	public Boolean checkProp(){
		try {
			//从控制台获得用户名和密码
			System.out.println("请输入用户名:");
			String username = sha256hex(new BufferedReader(
					new InputStreamReader(System.in)).readLine());
			System.out.println("请输入密码:");
			String password = sha256hex(new BufferedReader(
					new InputStreamReader(System.in)).readLine());
            StringBuffer sb= new StringBuffer("");
            FileReader reader = new FileReader(propFile);
            BufferedReader br = new BufferedReader(reader);
            String key1 = sha256hex(br.readLine());
            String key2 = sha256hex(br.readLine());
		      if(key1.equals(username) && key2.equals(password)){
		          return true;
		      }
            br.close();
            reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static void main(String[] args) {
		App lp = new App("/Users/zhangkehan/17205107/prop.txt");
		if(lp.checkProp()){
			System.out.println("登录成功！");
		}else
			System.out.println("用户名或密码错误！");
	}
	public static String sha256hex(String input) {
        return DigestUtils.sha256Hex(input);
    }
}